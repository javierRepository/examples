package com.interfaces;

import javax.script.ScriptEngine;

import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Element;

public interface AttributeOperations {

	public void inspectAttribute(Element child, Attributes nodesAttr,JsEngineOperations jsEngineOperations);

}
