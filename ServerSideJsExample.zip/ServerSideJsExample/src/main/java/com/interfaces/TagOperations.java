package com.interfaces;

import javax.script.ScriptEngine;

import org.jsoup.select.Elements;

public interface TagOperations {

	
	public void inspectTags (Elements children, JsEngineOperations jsEngineOperations);
}
