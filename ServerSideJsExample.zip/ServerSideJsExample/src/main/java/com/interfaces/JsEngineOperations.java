package com.interfaces;

import javax.script.ScriptEngine;

public interface JsEngineOperations {

	public Object executeJsScript(String script);
}
