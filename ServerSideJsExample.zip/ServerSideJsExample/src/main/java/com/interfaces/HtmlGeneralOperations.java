package com.interfaces;

import javax.script.ScriptEngine;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public interface HtmlGeneralOperations {

	public String getScript(Document doc);
	
	public Element getContent(Document doc,String tag);
	
	public Document parseHead(Document doc,JsEngineOperations jsEngineOperations);
	
	public Document parseBody(Document doc,JsEngineOperations jsEngineOperations);
}
