package com.interfaces;

import java.io.IOException;

import javax.script.ScriptEngine;
import javax.script.ScriptException;
import javax.servlet.http.HttpServletRequest;

import org.jsoup.nodes.Document;

public interface IndexService {

	public Document processHtml(Document doc,HttpServletRequest req) ;
}
