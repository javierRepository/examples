package com.interfacesImp;

import java.util.ArrayList;

import javax.script.ScriptEngine;

import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Element;

import com.interfaces.AttributeOperations;
import com.interfaces.JsEngineOperations;
import com.utilities.JSengineStaticFactory;
import com.utilities.Utilities;

public class AttributeOperationsImp implements AttributeOperations{
	
	
	
	public AttributeOperationsImp(){
	
	}
	//this method help the executeChildren to  parse and execute each one of the JS expression into the attributes.
	/**
	 * 
	 */
	public	void inspectAttribute (Element child,Attributes nodesAttr, JsEngineOperations jsEngineOperations){
		
		for(Attribute attr: nodesAttr){
			String attrKey = attr.getKey();
			String attrValue = attr.getValue();
			
			if(Utilities.checkEmptyValue(attrValue)){
				//we check what type of attribute is
				//everything is general unless -if and -for types
				String dataX = Utilities.checkDataKey(attrKey);
				
				switch (dataX){
					case "for":
						Utilities.concatAttrValue(attrValue);
						executeForLogic(child,attrValue,jsEngineOperations);
					break;
					
					case "if":
						Utilities.concatAttrValue(attrValue);
						executeIfLogic(child,nodesAttr,attrKey,attrValue,jsEngineOperations);
					break;
					
					default:
						executeDefault(attr,attrValue,jsEngineOperations);
					break;
				}
	
			}
		}
		
	}
		
	//This execute the -for logic for the -for attribute
	private void executeIfLogic(Element child,Attributes nodeAttr ,
								String attrKey, String attrValue,JsEngineOperations jsEngineOperations) {
		
		  //evaluation of the JS server-expression
		  boolean married  =  (boolean) jsEngineOperations.executeJsScript(attrValue);
		   if(!married){
			   child.remove();
			  
		   }else{
			   nodeAttr.remove(attrKey);
		   }	
	}
	
	//This executes the logic for the -if attribute
	private void executeForLogic(Element child, String attrValue,JsEngineOperations jsEngineOperations) {

		  //evaluation of the JS server-expression
		  ArrayList<String> children  = (ArrayList<String>) jsEngineOperations.executeJsScript(attrValue);
		   
		  if(children.size() > 0){
			   //for each child, make a div element with the name of the child
			   for(String kid : children){
				   Element div = new Element(child.tag(),"");
				   div.text("Child:"+kid.toString());
				   child.after(div);
			   }
		   }
		  child.remove();
	}

	//execute the JS expressions by the general way because they dont have the same structure and the -if and -for types
	private void executeDefault(Attribute attr, String attrValue,JsEngineOperations jsEngineOperations) {
		if(Utilities.containsCharSequence(attrValue)){
			attrValue=Utilities.isolateJsSecuence(attrValue);
			String p  =   jsEngineOperations.executeJsScript(attrValue).toString();
			attr.setValue(p);
			
		}
		
	}

}


