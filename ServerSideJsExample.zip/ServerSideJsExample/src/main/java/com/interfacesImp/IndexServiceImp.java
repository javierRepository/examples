package com.interfacesImp;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.jsoup.*;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.interfaces.HtmlGeneralOperations;
import com.interfaces.IndexService;
import com.interfaces.JsEngineOperations;
import com.pojo.Person;
import com.utilities.*;

import javax.script.*;
import javax.servlet.http.HttpServletRequest;

public class IndexServiceImp implements IndexService{

	
	private Document doc;
	private HtmlGeneralOperations htmlOperations;
	private JsEngineOperations jsEngineOperations;
	
	/**
	 * The reason to put the twoo first arguments in static way it is because no need of another elements to be created.
	 * Otherwise , the rest of them, need the previous ones to work.
	 */
	public IndexServiceImp(HtmlGeneralOperations htmlOperations,JsEngineOperations jsEngineOperations){
		
		
		this.htmlOperations = htmlOperations;
		this.jsEngineOperations = jsEngineOperations;
	}


	public Document processHtml(Document doc,HttpServletRequest req) {
		
		//Get the tamplate already parsed.
		doc = GetHtmlFromOriginFactory.parseDocument();
		
		//put the request param into the engine state.
		addRequestObjectToJsEngineState(req);
	
		
		//bring the content inside the script tag in String format
		String jsScript = htmlOperations.getScript(doc);
			
		//execute the script to begin with operations into the DOM
		jsEngineOperations.executeJsScript(jsScript);
		
		//render head Node
		doc = htmlOperations.parseHead(doc,jsEngineOperations);
		
		//render body node
		doc = htmlOperations.parseBody(doc,jsEngineOperations);
			
		return doc;
	}


	/**
	 * @param req
	 */
	private void addRequestObjectToJsEngineState(HttpServletRequest req) {
		JSengineStaticFactory.getInstance().put("request", req);
	}
}
