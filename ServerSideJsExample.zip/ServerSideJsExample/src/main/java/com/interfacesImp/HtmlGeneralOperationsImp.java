package com.interfacesImp;

import javax.script.ScriptEngine;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.interfaces.HtmlGeneralOperations;
import com.interfaces.JsEngineOperations;
import com.interfaces.TagOperations;
import com.utilities.GetHtmlFromOriginFactory;

public class HtmlGeneralOperationsImp implements HtmlGeneralOperations{
	
	private TagOperations tagOperations;
	
	public HtmlGeneralOperationsImp(){
		tagOperations = new TagOperationsImp();
		
	}
	
	//get the script from the Document, inside a "script" tag
	public String getScript(Document doc){
			String script=doc.data();
			String impScript =script.replaceAll("\r", "");
			return impScript;
	}

	//Get the content of a specificided tag
	public Element getContent(Document doc,String tag){
		
			return doc.getElementsByTag(tag).first();
	} 	
	
	//Parse the head node, after get it.
	public Document parseHead(Document doc,JsEngineOperations jsEngineOperations){
			Element head  = getContent(doc,"head");
			 Elements Hchildren = head.children();
			 if(Hchildren.size()>0)
				 tagOperations.inspectTags(Hchildren,jsEngineOperations);
			 return doc;
	}
	
	//Parse the body node after get it.
		public Document parseBody(Document doc,JsEngineOperations jsEngineOperations){
			Element body  = getContent(doc,"body");
			 Elements Bchildren = body.children();
			 //if children-body
			 if(Bchildren.size()>0)
				 tagOperations.inspectTags(Bchildren,jsEngineOperations);
			 return doc;
		}
}
