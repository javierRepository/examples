package com.interfacesImp;

import javax.script.ScriptEngine;
import javax.script.ScriptException;

import com.interfaces.JsEngineOperations;
import com.utilities.JSengineStaticFactory;

public class JsEngineOperationsImp implements JsEngineOperations{

	//Execute a piece of JS code
		public Object executeJsScript(String script){
			Object result= new Object();
			try {
				result = JSengineStaticFactory.getInstance().eval(script);
			} catch (ScriptException e) {
				e.printStackTrace();
			}
			return result;
		}
		
}
