package com.interfacesImp;

import java.util.ArrayList;

import javax.script.ScriptEngine;

import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.interfaces.AttributeOperations;
import com.interfaces.JsEngineOperations;
import com.interfaces.TagOperations;
import com.utilities.JSengineStaticFactory;
import com.utilities.Utilities;

public class TagOperationsImp implements TagOperations {

	private AttributeOperations attributeOperations;
	private ScriptEngine engine;
	
	public TagOperationsImp(){
		this.attributeOperations= new AttributeOperationsImp();
		this.engine= JSengineStaticFactory.getInstance();
	}
	
	
	//Parse the children of each TAG node
	public void inspectTags (Elements children,JsEngineOperations jsEngineOperations ){
			String childText =""; 
			
			for(Element child : children){
				//we search for the attributes  of this node
				Attributes NodesAttr = child.attributes();
				if (NodesAttr.size() >0)
					attributeOperations.inspectAttribute(child,NodesAttr,jsEngineOperations);
				
				//If not attributes we continue with the value of the tag.
				//In this case and the followings, I search for the server JS esxpressions and evaluate it with the JS engine.
				childText = child.text();
				if(Utilities.checkEmptyValue(childText) && Utilities.containsCharSequence(childText)){
					childText=Utilities.isolateJsSecuence(childText);
					
					if(!childText.equals("child")){
						childText=Utilities.concatAttrValue(childText);
						String p = jsEngineOperations.executeJsScript(childText).toString();
						child.text(p);
					}
				}
				
			}
	}
		
}	
