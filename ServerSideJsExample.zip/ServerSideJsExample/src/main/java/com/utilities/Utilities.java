package com.utilities;

import java.io.IOException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Utilities {
	
	//Helper methos to isolate a JS code secuence
	public static String isolateJsSecuence(String attrValue) {
		  int beginExpressionIndex=attrValue.indexOf("{");
		  int endExpressionIndex=attrValue.indexOf("}");
		   attrValue=attrValue.substring(beginExpressionIndex+1, endExpressionIndex);
		   return attrValue;
		
	}
	//Helper method to verify char secuence in a String
	public static boolean containsCharSequence(String attrValue) {
		if(attrValue.contains("${"))
			return true;
		
		return false;
		
	}
	
	//Helper method to concat ";" char to an String
	public static String concatAttrValue(String attrValue) {
		attrValue= attrValue.concat(";");	
		return attrValue;
	}
	
	//Helper method to check what type of logic attribute we are going to process.
	public static String checkDataKey(String attrKey) {
		String type = "";
		if(attrKey.contains("data-for-"))type="for";
		
		if(attrKey.contains("data-if"))type="if";
		
		return type;
	}
	
	//Helper method to verify is a String is empty
	public static boolean checkEmptyValue(String value) {
		if(value != null || !value.isEmpty())
			return true;
		return false;
		
	}
}
