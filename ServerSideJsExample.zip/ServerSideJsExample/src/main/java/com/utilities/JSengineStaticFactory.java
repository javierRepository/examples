package com.utilities;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class JSengineStaticFactory {
	
	private static final ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
	
	public static ScriptEngine getInstance(){

		return engine;
	}
	


}
