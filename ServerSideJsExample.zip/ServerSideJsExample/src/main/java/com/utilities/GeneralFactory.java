package com.utilities;



import com.interfaces.IndexService;
import com.interfacesImp.HtmlGeneralOperationsImp;
import com.interfacesImp.IndexServiceImp;
import com.interfacesImp.JsEngineOperationsImp;

public class GeneralFactory {
	
	public IndexService createOperationObjectsFactories (){
		return new IndexServiceImp(new HtmlGeneralOperationsImp(), new JsEngineOperationsImp());
	}

}
