package com.utilities;

import java.io.File;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class GetHtmlFromOriginFactory {

	
	//get the template from the webserver
		public static Document parseDocument() {
			File in = new File("src/main/resources/index.html");
			Document doc = null;
			try {
				doc = Jsoup.parse(in,"UTF-8");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return doc;
		}
}
