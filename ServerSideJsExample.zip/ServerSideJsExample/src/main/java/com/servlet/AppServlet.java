package com.servlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.nodes.Document;

import com.interfaces.IndexService;
import com.interfacesImp.IndexServiceImp;
import com.pojo.Person;
import com.utilities.GeneralFactory;
import com.utilities.GetHtmlFromOriginFactory;



public class AppServlet extends HttpServlet{
	
	 private IndexService indexService;
	 private Document doc;
	
	 public AppServlet() {
		
		this.indexService = new GeneralFactory().createOperationObjectsFactories();
	}
	 
	@Override
	public void doGet(HttpServletRequest req,HttpServletResponse res)  
			throws ServletException,IOException  
			{  
		Document doc = null;
		
		doc=indexService.processHtml(doc,req);
	
		 //RESPONSE
		 res.setContentType("text/html"); 
			PrintWriter pw=res.getWriter();
			pw.println(doc);
			pw.close();
			
			}
}
